package com.ximmerse.examples.xhawkinfo;

import java.text.DecimalFormat;
import java.util.Timer;
import java.util.TimerTask;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.ximmerse.core.XCobraController;
import com.ximmerse.core.XHawkApi;
import com.ximmerse.examples.xhawkinfo.R;


public class MainActivity extends ActionBarActivity {
	
    // <!-- TODO

	public static String[] sState=new String[]{
		"NOT_FOUND",
		"POSITION_FOUND",
		"ROTATION_FOUND",
		"POSE_FOUND"
	};

	public static String leftPad(String value,int totalWidth, char paddingChar){
		int i=value.length();
		if(i<totalWidth){
			i=totalWidth-i;
			StringBuilder sb=new StringBuilder();
			while(i-->0){
				sb.append(paddingChar);
			}
			value=sb.toString()+value;
		}
		return value;
	}

	public static String floatToString(float value,String format){
		DecimalFormat fnum=new DecimalFormat("##"+format);
		return fnum.format(value);
	}

	public static String vector3ToString(float[] value,String format){
		DecimalFormat fnum=new DecimalFormat("##"+format);
		int i=0;
		return "{x="+fnum.format(value[i++])+
				" y="+fnum.format(value[i++])+
				" z="+fnum.format(value[i++])+"}";
	}
	
	protected XCobraController[] mControllers;
	protected TextView[] mTexts;
	protected Timer mTimer;
	
    // TODO -->

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // <!-- TODO
        mTexts=new TextView[]{
        	(TextView)this.findViewById(R.id.textView0),
        	(TextView)this.findViewById(R.id.textView1)
        };
        //
        ((Button)this.findViewById(R.id.buttonStart0)).setOnClickListener(new OnClickListener(){
        	@Override
			public void onClick(View view) {
        		XHawkApi.sendMessage(XHawkApi.ID_XCOBRA_0,XHawkApi.MSG_TRIGGER,1,0);
        	}
        });
        //
        ((Button)this.findViewById(R.id.buttonStop0)).setOnClickListener(new OnClickListener(){
        	@Override
			public void onClick(View view) {
        		XHawkApi.sendMessage(XHawkApi.ID_XCOBRA_0,XHawkApi.MSG_TRIGGER,0,0);
        	}
        });
        //
        ((Button)this.findViewById(R.id.buttonStart1)).setOnClickListener(new OnClickListener(){
        	@Override
			public void onClick(View view) {
        		XHawkApi.sendMessage(XHawkApi.ID_XCOBRA_1,XHawkApi.MSG_TRIGGER,1,0);
        	}
        });
        //
        ((Button)this.findViewById(R.id.buttonStop1)).setOnClickListener(new OnClickListener(){
        	@Override
			public void onClick(View view) {
        		XHawkApi.sendMessage(XHawkApi.ID_XCOBRA_1,XHawkApi.MSG_TRIGGER,0,0);
        	}
        });
        //
        mControllers=new XCobraController[]{
        	new XCobraController(),
        	new XCobraController()
        };
        int ret=XHawkApi.init(this);
        mTimer=new Timer(true);
        mTimer.schedule(new TimerTask(){
        	@Override
			public void run() {
        		if(XHawkApi.sUsbStream.getIsOpen()){
        			MainActivity.this.runOnUiThread(updateUI);
        		}
			}
        },0,20);
        // TODO -->
        return;
    }

	@Override
    protected void onDestroy(){
        int ret=XHawkApi.exit();
		super.onDestroy();
	}
	
    // <!-- TODO

	protected Runnable updateUI=new Runnable(){
		@Override
		public void run(){
			XCobraController ctrl;
			TextView text;
			for(int i=0,imax=mControllers.length;i<imax;++i){
				ctrl=mControllers[i];
				text=mTexts[i];
				//
				XHawkApi.getJoystick(i, ctrl);
				if(ctrl.found_mask==0){
					text.setText("No X-Cobra Connected");
				}else{
					text.setText(
						String.format(
							"X-Cobra@%s\nState=%s\nJoystickX=%s\nJoystickY=%s\nTrigger=%s\nButtons=%s\nPosition=%s\nRotation=%s\n",
							i,
							sState[ctrl.found_mask],
							floatToString(ctrl.joystick_x,"0.000"),
							floatToString(ctrl.joystick_y,"0.000"),
							floatToString(ctrl.trigger,"0.000"),
							leftPad(Integer.toBinaryString(ctrl.buttons),8,'0'),
							vector3ToString(ctrl.position,"0.000"),
							vector3ToString(ctrl.eulerAngles,"0.000")
						)
					);
				}
			}
		}
	}; 
    // TODO -->

}